# Copy data directory to a temporary directory
cp -r ./data ./tmp-data

# Spawn Bitcoind, and provide execution permission.
docker compose up -d
mkdir -p logs
docker compose logs -f > logs/docker.log 2>&1 &

# wait for esplora to be ready
for i in {1..24}; do
  curl --fail -X GET http://localhost:8094/regtest/api/blocks/tip/height && break || sleep 1
done

cleanup() {
  exit_code=$?
  docker compose down -v
  rm -rf ./tmp-data
  exit $exit_code
}
trap cleanup EXIT

set -e  # Exit immediately if any command fails

chmod +x ./bash/run-bash.sh
chmod +x ./python/run-python.sh
chmod +x ./javascript/run-javascript.sh
chmod +x ./rust/run-rust.sh
chmod +x ./run.sh

# Run the test scripts
/bin/bash run.sh
npm run test
